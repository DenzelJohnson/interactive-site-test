import pandas as pd
import numpy as np
import requests
import time
import os
import folium
from pathlib import Path

from bokeh.plotting import figure
from bokeh.embed import components
from bokeh.resources import CDN
from bokeh.models import ColumnDataSource, LinearColorMapper, HoverTool
from bokeh.layouts import gridplot
from bokeh.palettes import Spectral11

# --- Geocode helper ---
def geocode_location(name):
    url = f"https://nominatim.openstreetmap.org/search"
    params = {"q": name, "format": "json", "limit": 1}
    headers = {"User-Agent": "travel-time-dashboard/1.0"}
    resp = requests.get(url, params=params, headers=headers)
    if resp.status_code == 200 and resp.json():
        d = resp.json()[0]
        return float(d["lat"]), float(d["lon"])
    return None, None

# --- Load and prep your data ---
data = pd.read_csv('data/comprehensive_travel_time_adjustments.csv')
origins      = sorted(data['Origin'].unique())
destinations = sorted(data['Destination'].unique())

# --- Geocode all unique locations and cache ---
coord_cache_file = 'data/location_coords.csv'
if os.path.exists(coord_cache_file):
    coords_df = pd.read_csv(coord_cache_file)
else:
    coords = []
    for loc in sorted(set(origins) | set(destinations)):
        lat, lon = geocode_location(loc)
        coords.append({"location": loc, "lat": lat, "lon": lon})
        time.sleep(1)  # be nice to the API
    coords_df = pd.DataFrame(coords)
    coords_df.to_csv(coord_cache_file, index=False)

loc2latlon = {row['location']: (row['lat'], row['lon']) for _, row in coords_df.iterrows()}

all_vals = data.iloc[:, 2:51].values.flatten().astype(float)
mapper = LinearColorMapper(palette=Spectral11, low=np.nanmin(all_vals), high=np.nanmax(all_vals))

# Create static directory if it doesn't exist
static_dir = Path("../static")
static_dir.mkdir(exist_ok=True)
js_dir = static_dir / "js"
js_dir.mkdir(exist_ok=True)

print("🔄 Generating Bokeh assets...")

# --- Build the full grid of small heatmaps (as Bokeh figures) ---
plots = []
plot_sources = []
for o in origins:
    row_plots = []
    row_srcs = []
    for d in destinations:
        sub = data[(data['Origin']==o)&(data['Destination']==d)]
        if not sub.empty:
            mat = sub.iloc[0,2:51].astype(float).values.reshape(7,7)
            xs  = np.repeat(np.arange(7), 7)
            ys  = np.tile(np.arange(7)[::-1], 7)
            vals= mat.flatten()
            src = ColumnDataSource({'x':xs,'y':ys,'val':vals, 'alpha':[1]*49}, name=f'src_{o}_{d}')

            p = figure(
                tools="hover",
                toolbar_location=None,
                x_range=(0,6), y_range=(0,6),
                sizing_mode='scale_both',
                width=120, height=120
            )
            p.rect('x','y',1,1, source=src, line_color=None,
                   fill_color={'field':'val','transform':mapper}, fill_alpha='alpha')
            hover = p.select_one(HoverTool)
            hover.tooltips = [
                ("Origin",      o),
                ("Destination", d),
                ("row (y)",     "@y"),
                ("col (x)",     "@x"),
                ("value",       "@val")
            ]
            p.axis.visible = False
        else:
            src = ColumnDataSource({'x':[], 'y':[], 'val':[], 'alpha':[]}, name=f'src_{o}_{d}')
            p = figure(width=120, height=120)
            p.axis.visible = False
        row_plots.append(p)
        row_srcs.append(src)
    plots.append(row_plots)
    plot_sources.append(row_srcs)

# Create the full grid
full_grid = gridplot(plots, sizing_mode='scale_both')

# Generate full grid script
full_script, full_div = components(full_grid)
full_script_content = full_script.replace('<script type="text/javascript">', '').replace('</script>', '').strip()

# Write the full grid script
full_js_path = js_dir / "bokeh_full_grid.js"
with open(full_js_path, 'w') as f:
    f.write(full_script_content)

print(f"✅ Full grid script written to {full_js_path}")

# --- Generate individual enlarged grids for each O-D pair ---
enlarged_scripts = {}
enlarged_divs = {}

for o in origins:
    for d in destinations:
        sub = data[(data['Origin']==o)&(data['Destination']==d)]
        if not sub.empty:
            mat = sub.iloc[0,2:51].astype(float).values.reshape(7,7)
            xs  = np.repeat(np.arange(7), 7)
            ys  = np.tile(np.arange(7)[::-1], 7)
            vals= mat.flatten()
            src = ColumnDataSource({'x':xs,'y':ys,'val':vals})

            # Create a separate color mapper for this plot
            enlarged_mapper = LinearColorMapper(palette=Spectral11, low=np.nanmin(all_vals), high=np.nanmax(all_vals))

            # Create enlarged figure (bigger than the grid squares)
            p = figure(
                tools="hover",
                toolbar_location=None,
                x_range=(0,6), y_range=(0,6),
                width=400, height=400,
                title=f"{o} → {d}"
            )
            p.rect('x','y',1,1, source=src, line_color=None,
                   fill_color={'field':'val','transform':enlarged_mapper})
            hover = p.select_one(HoverTool)
            hover.tooltips = [
                ("Origin",      o),
                ("Destination", d),
                ("row (y)",     "@y"),
                ("col (x)",     "@x"),
                ("value",       "@val{0.2f}")
            ]
            p.axis.visible = False
            
            # Generate script and div for this individual plot
            script, div = components(p)
            script_content = script.replace('<script type="text/javascript">', '').replace('</script>', '').strip()
            
            # Store the script and div
            enlarged_scripts[f"{o}_{d}"] = script_content
            enlarged_divs[f"{o}_{d}"] = div
        else:
            # Empty plot for missing data
            p = figure(width=400, height=400, title=f"{o} → {d} (No Data)")
            p.axis.visible = False
            script, div = components(p)
            script_content = script.replace('<script type="text/javascript">', '').replace('</script>', '').strip()
            enlarged_scripts[f"{o}_{d}"] = script_content
            enlarged_divs[f"{o}_{d}"] = div

print(f"✅ Generated {len(enlarged_scripts)} enlarged grid scripts")

# Prepare locations JS object and dropdowns from CSV
locations_js = '{\n' + ',\n'.join([
    f'  "{row["location"]}": {{lat: {row["lat"]}, lng: {row["lon"]}}}'
    for _, row in coords_df.iterrows()
]) + '\n}'
origin_options = '\n'.join([
    f'<option value="{row["location"]}">{row["location"]}</option>'
    for _, row in coords_df.iterrows()
])
dest_options = origin_options

# Generate JavaScript object containing all enlarged scripts
enlarged_scripts_js = "const enlargedScripts = {\n"
for key, script in enlarged_scripts.items():
    # Escape the script content for JavaScript
    escaped_script = script.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
    enlarged_scripts_js += f'  "{key}": "{escaped_script}",\n'
enlarged_scripts_js += "};\n"

# Generate JavaScript object containing all enlarged divs
enlarged_divs_js = "const enlargedDivs = {\n"
for key, div in enlarged_divs.items():
    # Escape the div content for JavaScript
    escaped_div = div.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
    enlarged_divs_js += f'  "{key}": "{escaped_div}",\n'
enlarged_divs_js += "};\n"

# Write enlarged grids data to JS file
enlarged_js_path = js_dir / "bokeh_enlarged_grids.js"
with open(enlarged_js_path, 'w') as f:
    f.write(enlarged_scripts_js)
    f.write(enlarged_divs_js)

print(f"✅ Enlarged grids data written to {enlarged_js_path}")

# Generate the new HTML with three-panel layout
html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>⎯⎯ Travel-Time Dashboard (Enhanced Layout) ⎯⎯</title>
  {CDN.render()}
  <style>
    body {{ font-family:sans-serif; margin:20px; }}
    
    .controls {{ 
      text-align: center; 
      margin-bottom: 20px; 
      padding: 15px;
      background: #f8f9fa;
      border-radius: 8px;
    }}
    
    .top-panel {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 30px;
      max-width: 1200px;
      margin-left: auto;
      margin-right: auto;
    }}
    
    #google-map {{
      width: 100%;
      height: 400px;
      border: 1px solid #ccc;
      border-radius: 8px;
    }}
    
    .enlarged-container {{
      border: 1px solid #ccc;
      border-radius: 8px;
      padding: 10px;
      background: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }}
    
    #enlarged-display {{
      width: 100%;
      height: 400px;
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    
    #heatmap-container {{ 
      width: 90vw;
      height: auto;
      max-width: 1200px;
      margin: 0 auto;
    }}
    
    .section-title {{
      font-size: 1.2em;
      font-weight: bold;
      margin-bottom: 10px;
      color: #333;
    }}
  </style>
</head>
<body>
  <h1>Travel-Time Dashboard (Enhanced Layout)</h1>
  
  <div class="controls">
    Origin:
    <select id="origin">{origin_options}</select>
    Destination:
    <select id="destination">{dest_options}</select>
    <button id="main-submit" onclick="updateAll()">Submit</button>
  </div>
  
  <div class="top-panel">
    <div>
      <div class="section-title">Route Map</div>
      <div id="google-map"></div>
    </div>
    <div class="enlarged-container">
      <div class="section-title">Selected Route Detail</div>
      <div id="enlarged-display">
        <p style="color: #666;">Select an origin-destination pair to view detailed travel times</p>
      </div>
    </div>
  </div>
  
  <div>
    <div class="section-title">All Origin-Destination Pairs</div>
    <div id="heatmap-container">
      {full_div}
    </div>
  </div>

  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBXbSYStWSMczRjNpmCR-kM_vYn2fGu8vk"></script>
  <script>
    const locations = {locations_js};
    let map, originMarker, destMarker, line;
    
    function initMap() {{
      map = new google.maps.Map(document.getElementById('google-map'), {{
        center: {{lat: 43.5, lng: -80.0}},
        zoom: 5
      }});
      updateMap();
    }}
    
    function updateMap() {{
      const originName = document.getElementById('origin').value;
      const destName = document.getElementById('destination').value;
      const origin = locations[originName];
      const destination = locations[destName];
      console.log('[Map] updateMap called with', originName, destName, origin, destination);
      if (!origin || !destination) return;
      if (originMarker) originMarker.setMap(null);
      if (destMarker) destMarker.setMap(null);
      if (line) line.setMap(null);
      originMarker = new google.maps.Marker({{
        position: origin,
        map: map,
        title: 'Origin: ' + originName,
        icon: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'
      }});
      destMarker = new google.maps.Marker({{
        position: destination,
        map: map,
        title: 'Destination: ' + destName,
        icon: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png'
      }});
      line = new google.maps.Polyline({{
        path: [origin, destination],
        geodesic: true,
        strokeColor: '#FF0000',
        strokeOpacity: 1.0,
        strokeWeight: 2,
        map: map
      }});
      const bounds = new google.maps.LatLngBounds();
      bounds.extend(origin);
      bounds.extend(destination);
      map.fitBounds(bounds);
    }}
    
    function updateEnlargedDisplay() {{
      const originName = document.getElementById('origin').value;
      const destName = document.getElementById('destination').value;
      const key = `${{originName}}_${{destName}}`;
      
      console.log('[Enlarged] Updating display for', key);
      
      const enlargedContainer = document.getElementById('enlarged-display');
      
      if (enlargedDivs[key] && enlargedScripts[key]) {{
        // Clear existing content
        enlargedContainer.innerHTML = enlargedDivs[key];
        
        // Execute the script for this enlarged plot
        try {{
          eval(enlargedScripts[key]);
        }} catch (e) {{
          console.error('[Enlarged] Error executing script:', e);
          enlargedContainer.innerHTML = '<p style="color: red;">Error loading enlarged view</p>';
        }}
      }} else {{
        enlargedContainer.innerHTML = '<p style="color: #666;">No data available for this route</p>';
      }}
    }}
    
    function accentuateGrid() {{
      const bokehDocs = window.Bokeh ? window.Bokeh.documents : [];
      if (!bokehDocs || bokehDocs.length === 0) {{
        console.log('[Grid] No Bokeh docs found');
        return;
      }}
      const doc = bokehDocs[0];
      const origins = {origins};
      const destinations = {destinations};
      const origin = document.getElementById('origin').value;
      const dest = document.getElementById('destination').value;
      console.log('[Grid] accentuateGrid called with', origin, dest);
      for (let i=0; i<origins.length; ++i) {{
        for (let j=0; j<destinations.length; ++j) {{
          let src = doc.get_model_by_name(`src_${{origins[i]}}_${{destinations[j]}}`);
          if (!src) continue;
          let is_selected = (origins[i] === origin && destinations[j] === dest);
          let new_alpha = src.data['alpha'].map(_ => is_selected ? 1 : 0.1);
          src.data['alpha'] = new_alpha;
          src.change.emit();
        }}
      }}
    }}
    
    // Unified update function
    function updateAll() {{
      console.log('[updateAll] Called');
      updateMap();
      updateEnlargedDisplay();
      accentuateGrid();
    }}
    
    window.onload = function() {{
      initMap();
      updateEnlargedDisplay();
      accentuateGrid();
      // Attach listeners
      document.getElementById('origin').addEventListener('change', updateAll);
      document.getElementById('destination').addEventListener('change', updateAll);
      document.getElementById('main-submit').addEventListener('click', updateAll);
    }};
  </script>
  
  <!-- Load the full grid script -->
  <script src="static/js/bokeh_full_grid.js"></script>
  <!-- Load the enlarged grids data -->
  <script src="static/js/bokeh_enlarged_grids.js"></script>
</body>
</html>
"""

# Write the enhanced HTML
with open("../project1.html", "w") as f:
    f.write(html)

print("✅ Enhanced HTML written to project1.html")
print("🎉 Enhanced dashboard complete with three-panel layout!")
print("📍 Layout: Map (left) + Enlarged Detail (right) + Full Grid (bottom)") 